# TemuTempat Malang — Project Android (uji coba)

Project ini membungkus website TemuTempat Malang ke dalam aplikasi Android WebView.
Termasuk file HTML awal dengan pencarian, filter budget/area/aktivitas, favorit sementara,
permintaan izin lokasi, filter perkiraan jarak/waktu, dan tautan rute Google Maps.

## Status penting
- Ini adalah **source project**, bukan file APK yang sudah dikompilasi.
- APK belum berhasil dibangun atau diuji di perangkat dari lingkungan pembuatan file ini.
- Data tempat, perkiraan harga, fasilitas, dan waktu tempuh belum seluruhnya diverifikasi.
- Waktu tempuh pada daftar adalah estimasi sederhana berdasarkan area kecamatan; Google Maps
  dibuka untuk memeriksa rute aktual.
- Favorit disimpan di memori halaman selama sesi terbuka, belum tersimpan permanen.
- Tidak membutuhkan Google Maps API key karena tombol peta membuka aplikasi/website Google Maps.

## Cara membuat APK menggunakan komputer
1. Pasang Android Studio versi stabil dan JDK yang direkomendasikan Android Studio.
2. Ekstrak ZIP project ini.
3. Android Studio → Open → pilih folder `TemuTempatMalang_Android`.
4. Tunggu Gradle Sync selesai. Jika diminta memasang Android SDK Platform 35, setujui.
5. Pilih menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. Setelah build sukses, tekan tautan **locate** pada notifikasi Android Studio. Umumnya APK ada di:
   `app/build/outputs/apk/debug/app-debug.apk`
7. Kirim APK itu ke HP Android, buka file tersebut, lalu izinkan pemasangan dari sumber yang digunakan
   jika Android meminta. Instal hanya APK yang kamu buat sendiri atau percayai.
8. Buka TemuTempat Malang dan izinkan lokasi saat diminta. Pastikan GPS/lokasi perangkat aktif.

## Fitur
- Tema hijau-krem dan tata letak responsif.
- Pencarian nama/area/kata kunci.
- Filter budget, jumlah orang, kategori, suasana, aktivitas, fasilitas indikatif, dan kecamatan.
- Lokasi perangkat melalui izin Android, estimasi jarak/waktu indikatif.
- Tombol buka pencarian/rute di Google Maps.
- Daftar favorit selama halaman terbuka.

## Catatan privasi
Lokasi hanya diminta saat pengguna menekan tombol lokasi. Aplikasi tidak memerlukan lokasi latar belakang.
Penolakan izin tidak menghalangi penggunaan fitur pencarian biasa.
